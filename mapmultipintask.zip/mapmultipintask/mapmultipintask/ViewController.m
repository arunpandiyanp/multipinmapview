//
//  ViewController.m
//  mapmultipintask
//
//  Created by Dinesh Jaganathan on 12/10/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<CLLocationManagerDelegate>


@end

@implementation ViewController

- (void)viewDidLoad {
    string=[[NSBundle mainBundle]pathForResource:@"test" ofType:@"plist"];
    dict=[[NSDictionary alloc]initWithContentsOfFile:string];
    NSLog(@"%@",dict);
  
    for(i=0;i<3;i++)
    {
        MKPointAnnotation *point=[[MKPointAnnotation alloc]init];
        center.latitude=[[[[dict valueForKey:@"Locations"]valueForKey:@"lat"]objectAtIndex:i]doubleValue];
        center.longitude=[[[[dict valueForKey:@"Locations"]valueForKey:@"lan"]objectAtIndex:i]doubleValue];
        NSLog(@"%f",center.latitude);

    point.coordinate=center;
    [map addAnnotation:point];
    }
    


    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
