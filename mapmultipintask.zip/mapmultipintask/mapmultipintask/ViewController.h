//
//  ViewController.h
//  mapmultipintask
//
//  Created by Dinesh Jaganathan on 12/10/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreFoundation/CoreFoundation.h>
@interface ViewController : UIViewController
{
    IBOutlet MKMapView *map;
    CLLocationCoordinate2D center;
    int i;
    NSMutableArray *array;
    NSArray *array1;
    NSString *string;
    NSDictionary *dict;
   
    


}
@end

